//
//  ImageCollectionCell.swift
//  MindTeck_Task
//
//  Created by Hari Krishna on 09/09/24.
//

import UIKit

class ImageCollectionCell: UICollectionViewCell {

    // Assuming you have an imageView inside your cell
    @IBOutlet weak var imageView: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        setupImageView()
    }

    private func setupImageView() {
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true // Ensure the image fits well within bounds
        imageView.layer.cornerRadius = 8 // Optional: add a rounded corner effect
    }

    // Configure the cell with image name or URL
    func configure(with imageName: String) {
        imageView.image = UIImage(named: imageName) // For local images
        // If loading from URL, use an image loading library or URLSession
    }
}

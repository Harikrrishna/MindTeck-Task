//
//  ListContentCell.swift
//  MindTeck_Task
//
//  Created by Hari Krishna on 09/09/24.
//

import UIKit

class ListContentCell: UITableViewCell {
    @IBOutlet weak var contentLbl: UILabel!
    @IBOutlet weak var imgVew: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        setupUI()
    }
    
    // Setup UI components if needed
    private func setupUI() {
        imgVew.contentMode = .scaleAspectFill
        imgVew.clipsToBounds = true
        contentLbl.textColor = .black
        contentLbl.font = UIFont.systemFont(ofSize: 16, weight: .medium)
    }
    // Method to configure the cell with DisplayItem data
    func configure(with item: DisplayItem) {
        contentLbl.text = item.title
        loadImage(from: item.imageUrl) // Load image from URL
    }
    // Helper method to load image from URL
    private func loadImage(from urlString: String) {
        guard let url = URL(string: urlString) else {
            imgVew.image = UIImage(named: "placeholder") // Use a placeholder if URL is invalid
            return
        }
        
        // Fetch the image asynchronously
        URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            if let data = data, error == nil {
                DispatchQueue.main.async {
                    self?.imgVew.image = UIImage(data: data)
                }
            } else {
                DispatchQueue.main.async {
                    self?.imgVew.image = UIImage(named: "placeholder") // Use a placeholder on failure
                }
            }
        }.resume()
    }
}

//
//  ContentViewModel.swift
//  MindTeck_Task
//
//  Created by Hari Krishna on 09/09/24.
//

import Foundation
enum DisplayItemType: Int, CaseIterable {
    case carousel = 0
    case search
    case content
    
    static func fromRawValue(_ rawValue: Int) -> DisplayItemType? {
        return DisplayItemType(rawValue: rawValue)
    }
}

struct DisplayItem {
    let title: String
    let imageUrl: String
    let type: DisplayItemType // New property to identify item type
}

class ContentViewModel {  // Renamed ViewModel to match the content it manages
    private let allItems: [DisplayItem] = {
        let carouselItems: [DisplayItem] = [
            DisplayItem(title: "Carousel Image 1", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/lathrop/asteroid_blend.png", type: .carousel),
            DisplayItem(title: "Carousel Image 2", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/lathrop/asteroid_blue.png", type: .carousel),
            DisplayItem(title: "Carousel Image 3", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/lathrop/nebula_blue.s2014.png", type: .carousel),
            DisplayItem(title: "Carousel Image 4", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/lathrop/explosion_orange.png", type: .carousel),
            DisplayItem(title: "Carousel Image 5", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/lathrop/splash.png", type: .carousel),
            DisplayItem(title: "Carousel Image 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/lathrop/shot3.png", type: .carousel),
            DisplayItem(title: "Carousel Image 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/lathrop/shot3.png", type: .carousel),
            DisplayItem(title: "Carousel Image 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/lathrop/shot3.png", type: .carousel),
            DisplayItem(title: "Carousel Image 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/lathrop/shot3.png", type: .carousel),
            DisplayItem(title: "Carousel Image 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/lathrop/shot3.png", type: .carousel),
            DisplayItem(title: "Carousel Image 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/lathrop/shot3.png", type: .carousel),
            DisplayItem(title: "Carousel Image 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/lathrop/shot3.png", type: .carousel),
            DisplayItem(title: "Carousel Image 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/lathrop/shot3.png", type: .carousel),
            DisplayItem(title: "Carousel Image 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/lathrop/shot3.png", type: .carousel),
            DisplayItem(title: "Carousel Image 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/lathrop/shot3.png", type: .carousel),
            DisplayItem(title: "Carousel Image 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/lathrop/shot3.png", type: .carousel),
            DisplayItem(title: "Carousel Image 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/lathrop/shot3.png", type: .carousel)

        ]
        
        let searchItems: [DisplayItem] = [
            DisplayItem(title: "Search Item 1", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/week6-emotions.png", type: .search),
            DisplayItem(title: "Search Item 2", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/week8-bunny_sprite.png", type: .search),
            DisplayItem(title: "Search Item 3", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/week8-dart.png", type: .search),
            DisplayItem(title: "Search Item 4", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/gutenberg.jpg", type: .search),
            DisplayItem(title: "Search Item 5", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/explosion.hasgraphics.png", type: .search),
            DisplayItem(title: "Search Item 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/week5-triangle.png", type: .search),
            DisplayItem(title: "Search Item 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/week5-triangle.png", type: .search),
            DisplayItem(title: "Search Item 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/week5-triangle.png", type: .search),
            DisplayItem(title: "Search Item 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/week5-triangle.png", type: .search),
            DisplayItem(title: "Search Item 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/week5-triangle.png", type: .search),
            DisplayItem(title: "Search Item 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/week5-triangle.png", type: .search),
            DisplayItem(title: "Search Item 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/week5-triangle.png", type: .search),
            DisplayItem(title: "Search Item 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/week5-triangle.png", type: .search),
            DisplayItem(title: "Search Item 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/week5-triangle.png", type: .search),
            DisplayItem(title: "Search Item 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/week5-triangle.png", type: .search),
            DisplayItem(title: "Search Item 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/week5-triangle.png", type: .search),
            DisplayItem(title: "Search Item 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/week5-triangle.png", type: .search),
            DisplayItem(title: "Search Item 6", imageUrl: "https://commondatastorage.googleapis.com/codeskulptor-assets/week5-triangle.png", type: .search)

        ]
        
        let contentItems: [DisplayItem] = [
            DisplayItem(title: "Content Item 1", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/alien_1_1.png", type: .content),
            DisplayItem(title: "Content Item 2", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/alien_1_2.png", type: .content),
            DisplayItem(title: "Content Item 3", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/back02.jpg", type: .content),
            DisplayItem(title: "Content Item 4", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/back03.jpg", type: .content),
            DisplayItem(title: "Content Item 5", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/back04.jpg", type: .content),
            DisplayItem(title: "Content Item 6", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/back05.jpg", type: .content),
            DisplayItem(title: "Content Item 7", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/back06.jpg", type: .content),
            DisplayItem(title: "Content Item 8", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/back07.jpg", type: .content),
            DisplayItem(title: "Content Item 8", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/back07.jpg", type: .content),
            DisplayItem(title: "Content Item 8", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/back07.jpg", type: .content),
            DisplayItem(title: "Content Item 8", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/back07.jpg", type: .content),
            DisplayItem(title: "Content Item 8", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/back07.jpg", type: .content),
            DisplayItem(title: "Content Item 8", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/back07.jpg", type: .content),
            DisplayItem(title: "Content Item 8", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/back07.jpg", type: .content),
            DisplayItem(title: "Content Item 8", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/back07.jpg", type: .content),
            DisplayItem(title: "Content Item 8", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/back07.jpg", type: .content),
            DisplayItem(title: "Content Item 8", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/back07.jpg", type: .content),
            DisplayItem(title: "Content Item 8", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/back07.jpg", type: .content),
            DisplayItem(title: "Content Item 8", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/back07.jpg", type: .content),
            DisplayItem(title: "Content Item 8", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/back07.jpg", type: .content),
            DisplayItem(title: "Content Item 8", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/back07.jpg", type: .content),
            DisplayItem(title: "Content Item 8", imageUrl: "https://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/back07.jpg", type: .content)

        ]
        
        // Merge all items into a single array
        return carouselItems + searchItems + contentItems
    }()
    
    
    // MARK: - Properties
    private(set) var items: [DisplayItem] = [] // All items
    private(set) var filteredItems: [DisplayItem] = [] // Filtered items for search
    
    
    // MARK: - Filter Items
    func filterItems(searchText: String) {
        if searchText.isEmpty {
            filteredItems = items
        } else {
            filteredItems = items.filter { $0.title.lowercased().contains(searchText.lowercased()) }
        }
    }
    
    // Method to parse the enum and return the appropriate data array
    func getDisplayItems(for cellType: DisplayItemType) -> [DisplayItem] {
        return allItems.filter({$0.type == cellType})
    }
}


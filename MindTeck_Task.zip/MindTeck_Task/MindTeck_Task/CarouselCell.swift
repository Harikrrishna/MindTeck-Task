//
//  CarouselCell.swift
//  MindTeck_Task
//
//  Created by Hari Krishna on 09/09/24.
//
import UIKit
protocol CarouselCellDelegate: AnyObject {
    func didChangePage(to pageNumber: Int)
}
class CarouselCell: UITableViewCell {
    
    // MARK: - Outlets
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var pageControl: UIPageControl!
    weak var delegate: CarouselCellDelegate? // Delegate property
    // MARK: - Properties
    var images: [String] = [] // Array to hold image URLs or names
    var itemWidth: CGFloat = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupCollectionView()
        setupPageControl()
    }
    
    private func setupCollectionView() {
        // Register the collection view cell
        let nib = UINib(nibName: "ImageCollectionCell", bundle: nil)
        collectionView.register(nib, forCellWithReuseIdentifier: "ImageCollectionCell")
        
        // Set the collection view's data source and delegate
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.isPagingEnabled = false
        collectionView.decelerationRate = .fast
        collectionView.showsHorizontalScrollIndicator = false // Hide horizontal indicator
        
        // Configure the layout
        let layout = UICollectionViewFlowLayout()
        itemWidth = collectionView.frame.width // Ensure the item width matches the collection view width
        layout.itemSize = CGSize(width: itemWidth, height: 320)
        layout.minimumLineSpacing = 0 // No spacing between items
        layout.scrollDirection = .horizontal
        collectionView.collectionViewLayout = layout
    }
    
    private func setupPageControl() {
        DispatchQueue.main.async {
            self.pageControl.numberOfPages = self.images.count
            self.pageControl.currentPage = 0
            self.pageControl.pageIndicatorTintColor = .lightGray
            self.pageControl.currentPageIndicatorTintColor = .black
            self.pageControl.addTarget(self, action: #selector(self.pageControlTapped(_:)), for: .valueChanged)
        }
    }
    
    // Configure the CarouselCell with images
    func configure(with images: [String]) {
        self.images = images
        collectionView.reloadData()
        pageControl.numberOfPages = images.count
    }
    
    // Action method when page control is tapped
    @objc private func pageControlTapped(_ sender: UIPageControl) {
        let indexPath = IndexPath(item: sender.currentPage, section: 0)
        collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
    }
}

extension CarouselCell: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    // MARK: - Collection View Data Source
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return images.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImageCollectionCell", for: indexPath) as? ImageCollectionCell else {
            return UICollectionViewCell()
        }
        let imageName = images[indexPath.row]
        cell.configure(with: imageName) // Configure cell with image
        return cell
    }
    
    // MARK: - Update Page Control on Scroll
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        // Update page control based on scroll
        let pageWidth = itemWidth
        let pageIndex = round(scrollView.contentOffset.x / pageWidth)
        pageControl.currentPage = Int(pageIndex)
    }
    
    // MARK: - Snap to Center
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        let pageWidth = itemWidth
        let targetXContentOffset = targetContentOffset.pointee.x
        let newPage = round(targetXContentOffset / pageWidth)
        
        pageControl.currentPage = Int(newPage)
        let point = CGPoint(x: newPage * pageWidth, y: targetContentOffset.pointee.y)
        targetContentOffset.pointee = point
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let pageWidth = collectionView.frame.width * 0.75
        let pageIndex = round(scrollView.contentOffset.x / pageWidth)
        pageControl.currentPage = Int(pageIndex)
        delegate?.didChangePage(to: Int(pageIndex))
    }
}

//
//  SearchCell.swift
//  MindTeck_Task
//
//  Created by Hari Krishna on 09/09/24.
//

import UIKit

class SearchCell: UITableViewCell {

    @IBOutlet weak var searchBar: UISearchBar!

    override func awakeFromNib() {
        super.awakeFromNib()
        setupSearchBar()
    }

    private func setupSearchBar() {
        searchBar.placeholder = "Search..."
        searchBar.searchBarStyle = .minimal
        searchBar.autocapitalizationType = .none
//        searchBar.returnKeyType = .done
    }
}

//
//  ContentViewController.swift
//  MindTeck_Task
//
//  Created by Hari Krishna on 05/09/24.
//

import UIKit

class ContentViewController: UIViewController {
    var images: [String] = ["bee", "ink", "bottle"]
    // MARK: - Outlets
    @IBOutlet weak var tableView: UITableView!
    var searchCell = SearchCell()
    // MARK: - Properties
    private var viewModel = ContentViewModel()
    var displayItems = [DisplayItem]()
    private var currentImageIndex: Int = 0
    var currentCarousel: DisplayItemType = .carousel
    // MARK: - View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.displayItems = viewModel.getDisplayItems(for: .carousel)
    }
    private func setupTableView() {
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "CarouselCell", bundle: nil), forCellReuseIdentifier: "CarouselCell")
        tableView.register(UINib(nibName: "SearchCell", bundle: nil), forCellReuseIdentifier: "SearchCell")
        tableView.register(UINib(nibName: "ListContentCell", bundle: nil), forCellReuseIdentifier: "ListContentCell")
    }
}

// MARK: - UITableView DataSource and Delegate Methods
extension ContentViewController: UITableViewDataSource, UITableViewDelegate {
    func lastSectionIndex() -> Int {
        // Get the total number of sections in the table view
        let sectionCount = tableView.numberOfSections
        // Return the index of the last section
        return sectionCount > 0 ? sectionCount - 1 : 0
    }
    func isLastSection(_ section: Int) -> Bool {
        return section == lastSectionIndex()
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return DisplayItemType.allCases.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isLastSection(section) {
            self.displayItems = viewModel.getDisplayItems(for: currentCarousel)
            let items = displayItems.filter { $0.type == currentCarousel }
            return items.count
        } else {
           return 1
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if isLastSection(indexPath.section) {
            // Handle content cell in the last section
            return configureListContentCell(for: indexPath)
        } else {
            // Handle other cells based on section
            switch indexPath.section {
            case 0:
                return configureCarouselCell(for: indexPath)
            case 1:
                return configureSearchCell(for: indexPath)
            default:
                return UITableViewCell() // Default fallback cell
            }
        }
    }

    // Configure content cell
    private func configureListContentCell(for indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ListContentCell", for: indexPath) as? ListContentCell else {
            return UITableViewCell() // Default fallback cell
        }
        self.displayItems = viewModel.getDisplayItems(for: currentCarousel)
        let items = displayItems.filter { $0.type == currentCarousel }
        if indexPath.row < items.count {
            cell.configure(with: items[indexPath.row])
        } else {
            cell.contentLbl.text = "No Content" // Fallback text
        }
        return cell
    }

    // Configure carousel cell
    private func configureCarouselCell(for indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "CarouselCell", for: indexPath) as? CarouselCell else {
            return UITableViewCell() // Default fallback cell
        }

        // Set images for the carousel cell
        cell.images = self.images
        cell.delegate = self
        return cell
    }

    // Configure search cell
    private func configureSearchCell(for indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "SearchCell", for: indexPath) as? SearchCell else {
            return UITableViewCell() // Default fallback cell
        }

        self.searchCell = cell
        cell.searchBar.delegate = self
        return cell
    }

    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        // Define heights for different cell types
        switch indexPath.section {
        case 0:
            return 350
        default:
            return 75
        }
    }
}

// MARK: - UISearchBar Delegate Methods
extension ContentViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        DispatchQueue.global(qos: .userInitiated).async {
            self.viewModel.filterItems(searchText: searchText)
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
}
extension ContentViewController: CarouselCellDelegate {
    func didChangePage(to pageNumber: Int) {
        if let itemType = DisplayItemType.fromRawValue(pageNumber) {
            currentCarousel = itemType
            // Optionally, you can filter or update content based on `currentCarousel`
//            let items = displayItems.filter { $0.type == currentCarousel }
            // Update the tableView or any relevant UI element
            tableView.reloadData()
        } else {
            // Handle invalid pageNumber if necessary
            print("Invalid page number")
        }
    }
}
